sizemarker=20;
optionmarker='x'
Corners= [
202, 315;
268, 163;
222, 89;
24, 30;
];

C0= [
204, 297;
198, 292;
190, 291;
201, 289;
192, 288;
213, 287;
190, 286;
192, 285;
203, 285;
206, 282;
213, 279;
183, 278;
196, 278;
197, 278;
199, 277;
208, 277;
204, 275;
198, 273;
199, 273;
214, 273;
215, 273;
216, 272;
217, 269;
209, 268;
215, 268;
217, 266;
205, 265;
205, 264;
216, 263;
214, 262;
218, 262;
216, 261;
207, 259;
220, 257;
213, 249;
210, 247;
210, 246;
212, 246;
219, 244;
212, 243;
211, 240;
213, 240;
216, 240;
213, 238;
218, 237;
219, 237;
210, 236;
210, 234;
215, 234;
213, 229;
217, 229;
209, 227;
218, 226;
211, 223;
212, 223;
217, 223;
214, 221;
210, 219;
217, 219;
211, 218;
215, 214;
216, 213;
214, 212;
217, 211;
209, 210;
215, 210;
210, 209;
211, 209;
217, 208;
246, 208;
242, 207;
244, 207;
220, 206;
240, 206;
247, 206;
235, 205;
241, 205;
244, 205;
233, 204;
236, 204;
237, 204;
238, 204;
246, 204;
209, 203;
215, 203;
226, 203;
238, 203;
244, 203;
245, 203;
246, 203;
250, 203;
231, 202;
248, 202;
249, 201;
218, 200;
227, 200;
233, 200;
236, 200;
239, 200;
245, 200;
246, 200;
219, 199;
226, 199;
230, 199;
233, 199;
235, 199;
238, 199;
246, 199;
247, 199;
209, 198;
210, 198;
218, 198;
233, 198;
239, 198;
244, 198;
210, 197;
220, 197;
222, 197;
223, 197;
228, 197;
240, 197;
243, 197;
248, 197;
211, 196;
219, 196;
222, 196;
225, 196;
244, 196;
211, 195;
215, 195;
217, 195;
246, 195;
248, 195;
211, 194;
212, 194;
215, 194;
220, 194;
222, 194;
225, 194;
228, 194;
213, 193;
245, 193;
246, 193;
248, 193;
223, 192;
225, 192;
244, 191;
246, 191;
216, 190;
245, 190;
247, 190;
244, 187;
246, 185;
244, 184;
245, 183;
243, 182;
246, 182;
243, 181;
244, 181;
243, 179;
245, 178;
246, 178;
243, 177;
244, 177;
261, 177;
242, 176;
258, 176;
260, 176;
261, 176;
260, 175;
262, 175;
243, 174;
258, 174;
260, 174;
261, 174;
241, 173;
244, 173;
254, 173;
258, 173;
260, 173;
261, 173;
262, 173;
242, 172;
255, 172;
256, 172;
258, 172;
259, 172;
260, 172;
262, 172;
241, 171;
251, 171;
255, 171;
257, 171;
260, 171;
261, 171;
241, 170;
242, 170;
243, 170;
246, 170;
248, 170;
253, 170;
254, 170;
258, 170;
244, 169;
248, 169;
249, 169;
250, 169;
253, 169;
254, 169;
255, 169;
259, 169;
241, 168;
242, 168;
244, 168;
248, 168;
254, 168;
259, 168;
261, 168;
244, 167;
245, 167;
247, 167;
250, 167;
251, 167;
252, 167;
260, 167;
261, 167;
240, 166;
241, 166;
242, 166;
243, 166;
245, 166;
246, 166;
248, 166;
249, 166;
258, 166;
259, 166;
242, 165;
247, 165;
248, 165;
258, 165;
260, 165;
242, 164;
243, 164;
247, 164;
257, 164;
258, 164;
241, 163;
242, 163;
244, 163;
257, 163;
259, 163;
243, 162;
257, 162;
258, 162;
259, 161;
257, 160;
256, 159;
257, 159;
265, 159;
257, 158;
255, 157;
257, 157;
263, 157;
256, 156;
257, 156;
258, 156;
255, 155;
255, 154;
261, 154;
258, 153;
259, 153;
260, 153;
261, 153;
256, 152;
257, 152;
258, 152;
259, 152;
260, 152;
256, 151;
257, 151;
259, 151;
254, 150;
255, 150;
256, 150;
258, 150;
254, 149;
256, 149;
257, 149;
254, 148;
255, 148;
256, 148;
]; 

C1= [
187, 290;
189, 285;
190, 281;
184, 279;
181, 278;
192, 278;
190, 276;
184, 275;
187, 275;
189, 270;
192, 270;
190, 269;
189, 263;
193, 263;
195, 262;
191, 261;
189, 260;
196, 260;
192, 259;
197, 259;
199, 259;
197, 253;
192, 252;
196, 252;
200, 249;
195, 248;
198, 248;
201, 248;
195, 245;
201, 245;
200, 243;
198, 237;
199, 235;
201, 235;
196, 233;
198, 232;
201, 232;
199, 231;
202, 230;
199, 227;
201, 225;
201, 224;
202, 224;
198, 223;
202, 223;
200, 219;
199, 214;
200, 214;
199, 213;
200, 211;
200, 210;
201, 210;
202, 209;
203, 207;
200, 205;
203, 205;
199, 199;
202, 199;
199, 197;
200, 197;
203, 197;
201, 196;
200, 194;
201, 192;
202, 192;
200, 191;
201, 189;
201, 187;
201, 186;
199, 185;
200, 182;
200, 181;
201, 181;
198, 180;
200, 179;
199, 178;
199, 176;
201, 176;
198, 173;
200, 173;
200, 171;
199, 169;
200, 168;
197, 167;
199, 167;
198, 165;
198, 164;
199, 163;
197, 160;
198, 160;
200, 160;
197, 157;
260, 157;
261, 157;
262, 157;
198, 156;
259, 156;
260, 156;
262, 156;
263, 156;
196, 155;
199, 155;
257, 155;
258, 155;
259, 155;
260, 155;
261, 155;
262, 155;
197, 154;
256, 154;
257, 154;
258, 154;
259, 154;
260, 154;
198, 153;
254, 153;
255, 153;
256, 153;
257, 153;
253, 152;
254, 152;
255, 152;
198, 151;
199, 151;
253, 151;
254, 151;
198, 150;
199, 150;
252, 150;
253, 150;
196, 149;
251, 149;
197, 148;
199, 148;
249, 148;
250, 148;
248, 147;
249, 147;
247, 146;
248, 146;
249, 146;
196, 145;
199, 145;
246, 145;
247, 145;
196, 144;
245, 144;
246, 144;
198, 143;
243, 143;
244, 143;
196, 142;
198, 142;
242, 142;
243, 142;
198, 141;
195, 140;
197, 140;
198, 140;
241, 140;
198, 139;
239, 139;
240, 139;
238, 138;
239, 138;
196, 137;
237, 137;
238, 137;
197, 136;
198, 136;
236, 136;
237, 136;
196, 135;
198, 135;
235, 135;
236, 135;
234, 134;
233, 133;
195, 132;
198, 132;
232, 132;
233, 132;
196, 131;
197, 131;
230, 131;
197, 130;
229, 130;
231, 130;
229, 129;
230, 129;
198, 128;
227, 128;
228, 128;
196, 127;
227, 127;
197, 126;
225, 126;
226, 126;
196, 125;
197, 125;
198, 125;
222, 125;
223, 125;
224, 125;
225, 125;
224, 124;
196, 123;
197, 123;
198, 123;
220, 123;
221, 123;
222, 123;
198, 122;
200, 122;
218, 122;
220, 122;
221, 122;
196, 121;
199, 121;
217, 121;
218, 121;
219, 121;
220, 121;
196, 120;
197, 120;
198, 120;
199, 120;
200, 120;
201, 120;
202, 120;
217, 120;
198, 119;
199, 119;
201, 119;
203, 119;
214, 119;
215, 119;
217, 119;
218, 119;
202, 118;
203, 118;
210, 118;
211, 118;
212, 118;
213, 118;
214, 118;
199, 117;
203, 117;
206, 117;
207, 117;
208, 117;
210, 117;
211, 117;
212, 117;
213, 117;
215, 117;
202, 116;
203, 116;
205, 116;
207, 116;
208, 116;
212, 116;
213, 116;
199, 115;
201, 115;
207, 115;
208, 115;
209, 115;
211, 115;
199, 114;
200, 114;
203, 114;
205, 114;
208, 114;
210, 114;
201, 113;
202, 113;
204, 113;
208, 113;
203, 112;
]; 

C2= [
135, 204;
132, 201;
136, 201;
140, 201;
143, 201;
134, 200;
144, 200;
145, 200;
137, 199;
140, 198;
146, 198;
147, 198;
154, 198;
148, 197;
149, 197;
150, 196;
151, 195;
155, 195;
158, 195;
161, 195;
156, 194;
164, 194;
165, 194;
152, 193;
158, 193;
167, 193;
161, 192;
162, 192;
165, 192;
168, 191;
171, 191;
166, 190;
171, 190;
168, 189;
171, 189;
173, 189;
177, 189;
172, 188;
174, 188;
177, 188;
173, 187;
179, 186;
174, 185;
181, 185;
176, 184;
179, 184;
182, 184;
179, 183;
183, 182;
184, 182;
180, 181;
184, 181;
181, 180;
184, 180;
184, 179;
185, 179;
187, 179;
185, 177;
186, 177;
187, 177;
188, 177;
189, 176;
191, 176;
188, 175;
188, 174;
189, 174;
191, 174;
193, 174;
190, 173;
191, 172;
194, 172;
191, 171;
195, 171;
192, 170;
193, 169;
195, 169;
196, 169;
197, 169;
197, 168;
198, 168;
194, 167;
196, 165;
197, 165;
197, 164;
199, 164;
201, 164;
197, 163;
198, 162;
202, 162;
199, 161;
201, 161;
199, 160;
202, 159;
203, 159;
204, 159;
200, 158;
201, 158;
202, 157;
203, 157;
205, 157;
203, 156;
204, 156;
204, 155;
205, 154;
206, 154;
205, 153;
207, 153;
209, 153;
205, 152;
206, 152;
207, 152;
209, 152;
211, 152;
207, 151;
213, 151;
208, 150;
209, 150;
210, 150;
211, 150;
212, 150;
215, 150;
216, 150;
217, 150;
211, 149;
212, 149;
213, 149;
214, 149;
216, 149;
218, 149;
219, 149;
220, 149;
221, 149;
222, 149;
223, 149;
225, 149;
226, 149;
228, 149;
229, 149;
230, 149;
231, 149;
232, 149;
233, 149;
213, 148;
215, 148;
217, 148;
220, 148;
221, 148;
222, 148;
223, 148;
224, 148;
225, 148;
226, 148;
227, 148;
228, 148;
229, 148;
231, 148;
232, 148;
233, 148;
234, 148;
235, 148;
236, 148;
215, 147;
216, 147;
217, 147;
219, 147;
220, 147;
221, 147;
222, 147;
224, 147;
225, 147;
226, 147;
227, 147;
230, 147;
232, 147;
234, 147;
236, 147;
237, 147;
235, 146;
236, 146;
237, 146;
238, 146;
236, 145;
237, 145;
238, 145;
239, 145;
237, 144;
238, 144;
239, 144;
238, 143;
239, 143;
240, 143;
240, 141;
239, 140;
240, 140;
241, 139;
240, 138;
241, 138;
242, 138;
241, 137;
242, 137;
242, 136;
243, 136;
241, 135;
242, 135;
243, 135;
244, 135;
250, 135;
242, 134;
243, 134;
244, 134;
245, 134;
246, 134;
247, 134;
248, 134;
249, 134;
243, 133;
244, 133;
245, 133;
246, 133;
248, 133;
]; 

T={C0 C1 C2 }; 

filename="T21.png"
r=[  255.00  102.00  255.00  255.00]
g=[    0.00  255.00  255.00   51.00]
b=[    0.00    0.00  102.00  204.00]
%colour formatting from labview (dividing by 255)
colours=[r; g; b]
colours=colours.'
colours=colours./255

% Main function
%function Main(filename, Curve, Corners)
    % get width and height of image
    Width=max(Corners(:, 1))
    Height=max(Corners(:, 2))
    legstring=[] %legend to construct
    f=figure, %figure to draw
    % 1. Step: Order Corners
    [A,B,C,D] = orderCorners(Corners);

    % 2. Step: Calculate Matrix
    M = computeM(A, B, C, D, Width, Height);

    for i = 1:length(T) %for all traces, to calculate the fit and to plot the fit
        Curves=cell2mat(T(i));
        X = Curves(:,1);
        Y = Curves(:,2);

        % 3. Step: Apply M
        [x y] = applyM(M, X, Y);

        % 4. Step: Fit curve
        [ParamStr yfitted] = FindTrace(x, y, Width, Height);

        %Step 5, plotting
        %plot fitted line (data needs to be sorted by x so it can fit the
        %lines)
        %resize the original data so it fits on the graph (W=1s, H=2v)
        xresized=x./Width
        yresized=y./(0.5*Height)-1
        %plot the fitted data
        [xsort, index]=sort(xresized)
        ysort=yfitted(index)
        plot(xsort, ysort, 'color', colours(i,:));
        %construct the legend
        legstring=[legstring ParamStr]
        hold on;
    end
    %output the legend
    lgd=legend(legstring)
    lgd.AutoUpdate ="off";
    lgd.Location='southoutside'
    %6. Step plot original data
    for i = 1:length(T) %for all traces
        Curves=cell2mat(T(i));
        X = Curves(:,1); 
        Y = Curves(:,2);
        [x y] = applyM(M, X, Y);
        %resize the original data so it fits on the graph (W=1s, H=2v)
        xresized=x./Width
        yresized=y./(0.5*Height)-1
        %plot original data points
        plot(xresized, yresized, optionmarker, 'color', colours(i, :), 'MarkerSize', sizemarker);
        hold on;
    end
    hold off;

    %add title
    [filepath,name,ext] = fileparts(filename)
    t=datestr(datetime)
    titre=strcat("SRC : ‘", name, ext, "’ @ ", t)
    title(titre)
    %add grid lines and axis labels
    grid on;
    xticks(0:0.1:1)
    yticks([-1:0.2:1])
    axis([0 1 -1 1])
    yline(0);
    xline(0.5);
    xlabel("0.1[s]/div")
    ylabel("0.2[v]/div")
    %7. Step pdf file
    pdffilename=strcat(name, ".pdf")
    saveas(f, pdffilename)
    %TODO axis labeling, main axis highlighted
%end
%end of main function


% function to apply M to "untangle" the coordinates to homogenuous coordinates
function [x y] = applyM(M, X, Y) 
    point = [X Y]     
    point(:, end+1)=1       % homogenuous coordinates
    newpoint= M*point.';
    point_transformed=newpoint.';
    x=point_transformed(:, 1)./point_transformed(:, 3)
    y=point_transformed(:, 2)./point_transformed(:, 3)
end



% function to compute matrix M
function M = computeM(A,B,C, D, Width, Height)
    %corner A goes to 0 0
    %corner B goes to W 0
    %corner C goes to W H
    %corner D goes to 0 H
    matrix=[A(1), A(2), 1, 0, 0, 0, -A(1)*0, -A(2)*0;
            0, 0, 0, A(1), A(2), 1, -A(1)*0, -A(2)*0;
            B(1), B(2), 1, 0, 0, 0, -B(1)*Width, -B(2)*Width;
            0, 0, 0, B(1), B(2), 1, -B(1)*0, -B(2)*0;
            C(1), C(2), 1, 0, 0, 0, -C(1)*Width, -C(2)*Width;
            0, 0, 0, C(1), C(2), 1, -C(1)*Height, -C(2)*Height;
            D(1), D(2), 1, 0, 0, 0, -D(1)*0, -D(2)*0;
            0, 0, 0, D(1), D(2), 1, -D(1)*Height, -D(2)*Height;]
    b=[0; 0; Width; 0; Width; Height; 0; Height]
    
    % Matrix division Ax=b => x = A\b
    x=matrix\b 
    M=[x(1), x(2), x(3);
        x(4), x(5), x(6);
        x(7), x(8), 1
        ] 
end



function  [ParamStr, yfitted] = FindTrace(X, Y, Width, Height)
    %resize the data such that width is 1s and height is 2v
    X=X./(Width)
    Y=Y./(Height*0.5)-1
    %plot(X, Y, 'ob'); DEBUG
    %hold on;
    %try plotting a sine
    %to find frequency, approximate as a 12deg polyn
    [Xsort, index]=sort(X)
    Ysort=Y(index)
    polyn = polyfit(Xsort,Ysort,12);
    %find the points where the polyn is mean(Y)
    polyn(end)=polyn(end)-mean(Y) %to solve polym=mean(Y)
    sols=roots(polyn)
    Xmax=max(X);
    sols=sols(find(0<sols & sols<Xmax & conj(sols)==sols)) %check if solutions are in domain and real
    if length(sols)<3 & 1<length(sols)
        dist=sols(end)-sols(end-1)
    elseif length(sols)==1 %this is probably gonna be a polynomial
            dist=max(X)-min(X)
    else dist=sols(end-1)-sols(end-2)
    end

    opts = fitoptions('Method','NonlinearLeastSquares');
    ft=fittype('a*sin(b*x+c)+d');
    [sortY, index]=sort(Y, 'descend');
    omega=dist
    opts.StartPoint=[abs((max(Y)-min(Y))/2), pi/abs(omega), Y(1), mean(Y)]
    [fitResult, gofsine, output] = fit(X, Y, ft, opts );
    %plot(fitResult); DEBUG
    %try plotting a 4 degree polynomial
    [polyn4, gofpolyn] = fit(Xsort,Ysort,'poly4');
    %check the gofs and pick the lowest one
    if gofpolyn.rmse< gofsine.rmse
        %output polynomial coefficients
        ParamStr=sprintf("a4: %.2f, a3: %.2f, a2: %.2f, a1: %.2f, RMSE: %.2f", polyn4(1), polyn4(2), polyn4(3), polyn4(4), gofpolyn.rmse)
        yfitted=polyn4(X);
    else
        %output afpo of sine in paramstr
        ParamStr=sprintf("A: %.2f[v], DC: %.2f[v], F: %.2f[Hz], P: %.2f [deg], RMSE: %.2f", fitResult.a, fitResult.d, fitResult.b/(2*pi), rad2deg(fitResult.c), gofsine.rmse)
        yfitted=fitResult(X);
    end
end


%function to order corners
function [A,B,C,D] = orderCorners(Corners)
%must find corner A by sorting the Corners over the smallest distance to
%0,0, that is to say smallest x2+y2
distances=Corners(:,1).^2 + Corners(:,2).^2
[distances, index_distances]=sort(distances)
xA=Corners(index_distances(1), 1);
yA=Corners(index_distances(1), 2);
A=[xA, yA];
%put A at the beginning of Corners
aux=[Corners(1, 1), Corners(1, 2)]
Corners(index_distances(1), :)=aux
Corners(1, :)=A
%now we must order the B C D such that atan((y-yA)/(x-xA)) is minimal
angles=atan2((Corners(:, 2)-yA),(Corners(:, 1)-xA))
angles(1, :)=[] %delete A
%we copy corners and we delete A from it as well
CornersCopy=Corners;
CornersCopy(1, :)=[] %delete A
[angles, index_angles]=sort(angles)
%now the last 3 angles correspond to B C and D
B=[CornersCopy(index_angles(1), 1), CornersCopy(index_angles(1), 2)];
C=[CornersCopy(index_angles(2), 1), CornersCopy(index_angles(2), 2)];
D=[CornersCopy(index_angles(3), 1), CornersCopy(index_angles(3), 2)];
end
   