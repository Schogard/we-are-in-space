sizemarker=4;
optionmarker='o'
Corners= [
83, 500;
416, 282;
466, 38;
395, 32;
];

C0= [
385, 122;
386, 122;
387, 122;
382, 121;
383, 121;
384, 121;
385, 121;
389, 121;
390, 121;
391, 121;
392, 121;
380, 120;
381, 120;
392, 120;
393, 120;
394, 120;
379, 119;
380, 119;
394, 119;
395, 119;
396, 119;
378, 118;
379, 118;
396, 118;
397, 118;
378, 117;
398, 117;
399, 117;
377, 116;
378, 116;
400, 116;
377, 115;
401, 115;
402, 115;
377, 114;
402, 114;
403, 114;
376, 113;
404, 113;
376, 112;
376, 111;
406, 111;
407, 111;
376, 110;
408, 110;
375, 109;
409, 109;
375, 108;
410, 108;
375, 107;
411, 107;
375, 106;
412, 106;
375, 105;
413, 105;
375, 104;
414, 104;
375, 103;
415, 103;
416, 103;
375, 102;
416, 102;
417, 101;
375, 98;
420, 98;
421, 97;
375, 96;
421, 96;
422, 96;
375, 95;
422, 95;
423, 95;
375, 94;
423, 94;
424, 94;
375, 93;
424, 93;
375, 92;
375, 91;
426, 91;
375, 90;
427, 90;
375, 89;
428, 89;
375, 88;
428, 88;
429, 88;
375, 87;
429, 87;
430, 87;
376, 86;
430, 86;
376, 85;
431, 85;
376, 84;
432, 84;
376, 83;
433, 83;
376, 82;
434, 82;
376, 81;
434, 81;
376, 80;
435, 80;
377, 79;
436, 79;
377, 78;
437, 78;
377, 77;
437, 77;
438, 77;
377, 76;
438, 76;
377, 75;
439, 75;
378, 74;
440, 74;
378, 73;
441, 73;
378, 72;
441, 72;
378, 71;
442, 71;
378, 70;
443, 70;
379, 69;
444, 69;
379, 68;
444, 68;
379, 67;
445, 67;
379, 66;
380, 65;
447, 65;
380, 64;
448, 64;
380, 63;
448, 63;
449, 63;
380, 62;
449, 62;
380, 61;
450, 61;
381, 59;
451, 59;
381, 58;
452, 58;
382, 57;
453, 57;
382, 56;
453, 56;
454, 56;
382, 55;
454, 55;
455, 55;
382, 54;
455, 54;
383, 53;
456, 53;
383, 52;
457, 52;
458, 51;
458, 50;
459, 50;
459, 49;
460, 49;
460, 48;
461, 48;
461, 47;
462, 47;
462, 46;
463, 45;
]; 

C1= [
434, 190;
433, 188;
433, 187;
433, 186;
433, 185;
433, 184;
432, 183;
432, 182;
432, 181;
432, 180;
431, 179;
431, 178;
431, 177;
431, 176;
430, 175;
430, 174;
430, 173;
430, 172;
429, 171;
430, 171;
429, 170;
429, 169;
429, 168;
428, 167;
428, 166;
428, 165;
428, 164;
428, 163;
427, 162;
427, 161;
427, 160;
426, 159;
426, 158;
426, 157;
426, 156;
425, 155;
425, 154;
425, 153;
424, 152;
425, 152;
424, 151;
424, 150;
424, 149;
423, 146;
422, 145;
422, 144;
422, 143;
422, 142;
421, 141;
421, 140;
420, 139;
421, 139;
420, 138;
420, 137;
419, 135;
419, 134;
418, 133;
419, 133;
418, 132;
418, 131;
417, 130;
417, 129;
417, 128;
416, 127;
416, 126;
415, 125;
416, 125;
415, 124;
414, 123;
415, 123;
414, 122;
414, 121;
413, 120;
414, 120;
413, 119;
413, 118;
411, 116;
411, 115;
409, 112;
410, 112;
409, 111;
409, 110;
408, 109;
407, 108;
408, 108;
407, 107;
406, 106;
407, 106;
406, 105;
405, 104;
404, 103;
405, 103;
404, 102;
403, 101;
404, 101;
403, 100;
402, 99;
401, 98;
402, 98;
400, 97;
401, 97;
398, 94;
399, 94;
397, 93;
398, 93;
397, 92;
396, 91;
395, 90;
396, 90;
394, 89;
395, 89;
393, 88;
394, 88;
392, 87;
393, 87;
391, 86;
392, 86;
390, 85;
391, 85;
389, 84;
390, 84;
388, 83;
389, 83;
386, 82;
387, 82;
385, 81;
384, 80;
385, 80;
383, 79;
384, 79;
381, 78;
382, 78;
379, 77;
380, 77;
381, 77;
378, 76;
379, 76;
376, 75;
374, 74;
375, 74;
376, 74;
372, 73;
373, 73;
374, 73;
370, 72;
371, 72;
]; 

C2= [
443, 143;
443, 142;
442, 141;
441, 140;
442, 140;
441, 139;
440, 138;
441, 138;
439, 137;
440, 137;
438, 136;
439, 136;
438, 135;
437, 134;
436, 133;
437, 133;
434, 131;
435, 131;
433, 130;
434, 130;
432, 129;
433, 129;
431, 128;
432, 128;
430, 127;
431, 127;
430, 126;
428, 125;
427, 124;
428, 124;
426, 123;
427, 123;
425, 122;
423, 121;
424, 121;
422, 120;
423, 120;
420, 119;
421, 119;
339, 118;
340, 118;
341, 118;
419, 118;
420, 118;
341, 117;
342, 117;
343, 117;
344, 117;
417, 117;
418, 117;
344, 116;
345, 116;
346, 116;
347, 116;
415, 116;
416, 116;
417, 116;
348, 115;
349, 115;
350, 115;
414, 115;
415, 115;
351, 114;
352, 114;
353, 114;
354, 114;
410, 114;
411, 114;
412, 114;
355, 113;
356, 113;
357, 113;
358, 113;
408, 113;
409, 113;
410, 113;
358, 112;
359, 112;
360, 112;
361, 112;
362, 112;
405, 112;
406, 112;
407, 112;
408, 112;
363, 111;
364, 111;
365, 111;
366, 111;
367, 111;
368, 111;
401, 111;
402, 111;
403, 111;
404, 111;
405, 111;
368, 110;
369, 110;
371, 110;
372, 110;
373, 110;
374, 110;
375, 110;
395, 110;
396, 110;
397, 110;
398, 110;
399, 110;
400, 110;
401, 110;
376, 109;
377, 109;
378, 109;
379, 109;
380, 109;
381, 109;
382, 109;
383, 109;
384, 109;
385, 109;
386, 109;
387, 109;
388, 109;
389, 109;
390, 109;
391, 109;
392, 109;
393, 109;
395, 109;
]; 

C3= [
368, 123;
369, 123;
370, 123;
364, 122;
365, 122;
366, 122;
367, 122;
371, 122;
372, 122;
373, 122;
374, 122;
375, 122;
376, 122;
377, 122;
362, 121;
378, 121;
379, 121;
380, 121;
381, 121;
360, 120;
361, 120;
382, 120;
383, 120;
384, 120;
385, 120;
360, 119;
385, 119;
386, 119;
387, 119;
388, 119;
359, 118;
391, 118;
359, 117;
392, 117;
393, 117;
394, 117;
395, 117;
358, 116;
395, 116;
396, 116;
397, 116;
398, 116;
399, 116;
358, 115;
399, 115;
400, 115;
358, 114;
404, 114;
405, 114;
406, 114;
407, 114;
407, 113;
411, 113;
412, 113;
357, 112;
413, 112;
415, 112;
416, 112;
417, 112;
418, 112;
419, 112;
420, 112;
421, 112;
422, 112;
357, 111;
422, 111;
423, 111;
424, 111;
425, 111;
426, 111;
427, 111;
428, 111;
429, 111;
430, 111;
431, 111;
432, 111;
434, 111;
357, 110;
435, 110;
436, 110;
437, 110;
438, 110;
439, 110;
440, 110;
441, 110;
357, 109;
441, 109;
442, 109;
443, 109;
444, 109;
445, 109;
446, 109;
357, 108;
447, 108;
448, 108;
449, 108;
450, 108;
357, 107;
357, 106;
357, 105;
357, 104;
357, 103;
358, 102;
358, 101;
358, 100;
358, 99;
358, 97;
359, 96;
359, 95;
359, 94;
359, 93;
360, 92;
360, 90;
360, 89;
361, 88;
361, 87;
361, 86;
362, 84;
362, 83;
363, 82;
]; 

C4= [
320, 147;
321, 146;
322, 145;
323, 144;
325, 143;
326, 142;
327, 141;
328, 140;
329, 139;
330, 138;
331, 137;
332, 136;
334, 135;
335, 134;
336, 134;
337, 133;
338, 132;
339, 131;
340, 130;
341, 130;
341, 129;
342, 128;
343, 127;
344, 127;
345, 126;
346, 125;
347, 125;
348, 124;
350, 122;
351, 122;
352, 121;
353, 121;
353, 120;
354, 119;
355, 119;
356, 118;
357, 117;
358, 117;
359, 116;
360, 116;
361, 115;
362, 114;
363, 114;
364, 113;
365, 113;
451, 113;
365, 112;
366, 112;
367, 112;
423, 112;
424, 112;
425, 112;
426, 112;
427, 112;
450, 112;
413, 111;
418, 111;
419, 111;
448, 111;
410, 110;
411, 110;
412, 110;
413, 110;
442, 110;
443, 110;
444, 110;
445, 110;
446, 110;
447, 110;
371, 109;
372, 109;
373, 109;
406, 109;
407, 109;
374, 108;
403, 108;
404, 108;
405, 108;
406, 108;
376, 107;
377, 107;
378, 107;
379, 107;
400, 107;
401, 107;
402, 107;
403, 107;
379, 106;
380, 106;
381, 106;
382, 106;
383, 106;
396, 106;
397, 106;
398, 106;
399, 106;
383, 105;
384, 105;
385, 105;
386, 105;
387, 105;
388, 105;
389, 105;
390, 105;
391, 105;
392, 105;
393, 105;
394, 105;
]; 

T={C0 C1 C2 C3 C4 }; 

filename="T22.png"
r=[  255.00  153.00  255.00    0.00   51.00  102.00]
g=[    0.00  102.00    0.00    0.00  255.00    0.00]
b=[    0.00   51.00  255.00  255.00    0.00  102.00]
%colour formatting from labview (dividing by 255)
colours=[r; g; b]
colours=colours.'
colours=colours./255

% Main function
%function Main(filename, Curve, Corners)
    % get width and height of image
    Width=max(Corners(:, 1))
    Height=max(Corners(:, 2))
    legstring=[] %legend to construct
    f=figure, %figure to draw
    % 1. Step: Order Corners
    [A,B,C,D] = orderCorners(Corners);

    % 2. Step: Calculate Matrix
    M = computeM(A, B, C, D, Width, Height);

    for i = 1:length(T) %for all traces, to calculate the fit and to plot the fit
        Curves=cell2mat(T(i));
        X = Curves(:,1);
        Y = Curves(:,2);

        % 3. Step: Apply M
        [x y] = applyM(M, X, Y);

        % 4. Step: Fit curve
        [ParamStr yfitted] = FindTrace(x, y, Width, Height);

        %Step 5, plotting
        %plot fitted line (data needs to be sorted by x so it can fit the
        %lines)
        %resize the original data so it fits on the graph (W=1s, H=2v)
        xresized=x./Width
        yresized=y./(0.5*Height)-1
        %plot the fitted data
        [xsort, index]=sort(xresized)
        ysort=yfitted(index)
        plot(xsort, ysort, 'color', colours(i+1,:));
        %construct the legend
        legstring=[legstring ParamStr]
        hold on;
    end
    %output the legend
    lgd=legend(legstring)
    lgd.AutoUpdate ="off";
    lgd.Location='southoutside'
    %6. Step plot original data
    for i = 1:length(T) %for all traces
        Curves=cell2mat(T(i));
        X = Curves(:,1); 
        Y = Curves(:,2);
        [x y] = applyM(M, X, Y);
        %resize the original data so it fits on the graph (W=1s, H=2v)
        xresized=x./Width
        yresized=y./(0.5*Height)-1
        %plot original data points
        plot(xresized, yresized, optionmarker, 'color', colours(i+1, :), 'MarkerSize', sizemarker);
        hold on;
    end
    hold off;

    %add title
    [filepath,name,ext] = fileparts(filename)
    t=datestr(datetime)
    titre=strcat("SRC : ‘", name, ext, "’ @ ", t)
    title(titre)
    %add grid lines and axis labels
    grid on;
    xticks(0:0.1:1)
    yticks([-1:0.2:1])
    axis([0 1 -1 1])
    yline(0);
    xline(0.5);
    xlabel("0.1[s]/div")
    ylabel("0.2[v]/div")
    %7. Step pdf file
    pdffilename=strcat(name, ".pdf")
    saveas(f, pdffilename)
    %TODO axis labeling, main axis highlighted
%end
%end of main function


% function to apply M to "untangle" the coordinates to homogenuous coordinates
function [x y] = applyM(M, X, Y) 
    point = [X Y]     
    point(:, end+1)=1       % homogenuous coordinates
    newpoint= M*point.';
    point_transformed=newpoint.';
    x=point_transformed(:, 1)./point_transformed(:, 3)
    y=point_transformed(:, 2)./point_transformed(:, 3)
end



% function to compute matrix M
function M = computeM(A,B,C, D, Width, Height)
    %corner A goes to 0 0
    %corner B goes to W 0
    %corner C goes to W H
    %corner D goes to 0 H
    matrix=[A(1), A(2), 1, 0, 0, 0, -A(1)*0, -A(2)*0;
            0, 0, 0, A(1), A(2), 1, -A(1)*0, -A(2)*0;
            B(1), B(2), 1, 0, 0, 0, -B(1)*Width, -B(2)*Width;
            0, 0, 0, B(1), B(2), 1, -B(1)*0, -B(2)*0;
            C(1), C(2), 1, 0, 0, 0, -C(1)*Width, -C(2)*Width;
            0, 0, 0, C(1), C(2), 1, -C(1)*Height, -C(2)*Height;
            D(1), D(2), 1, 0, 0, 0, -D(1)*0, -D(2)*0;
            0, 0, 0, D(1), D(2), 1, -D(1)*Height, -D(2)*Height;]
    b=[0; 0; Width; 0; Width; Height; 0; Height]
    
    % Matrix division Ax=b => x = A\b
    x=matrix\b 
    M=[x(1), x(2), x(3);
        x(4), x(5), x(6);
        x(7), x(8), 1
        ] 
end



function  [ParamStr, yfitted] = FindTrace(X, Y, Width, Height)
    %resize the data such that width is 1s and height is 2v
    X=X./(Width)
    Y=Y./(Height*0.5)-1
    %plot(X, Y, 'ob'); DEBUG
    %hold on;
    %try plotting a sine
    %to find frequency, approximate as a 12deg polyn
    [Xsort, index]=sort(X)
    Ysort=Y(index)
    polyn = polyfit(Xsort,Ysort,12);
    %find the points where the polyn is mean(Y)
    polyn(end)=polyn(end)-mean(Y) %to solve polym=mean(Y)
    sols=roots(polyn)
    Xmax=max(X);
    sols=sols(find(0<sols & sols<Xmax & conj(sols)==sols)) %check if solutions are in domain and real
    if length(sols)<3 & 1<length(sols)
        dist=sols(end)-sols(end-1)
    elseif length(sols)==1 %this is probably gonna be a polynomial
            dist=max(X)-min(X)
    else dist=sols(end-1)-sols(end-2)
    end

    opts = fitoptions('Method','NonlinearLeastSquares');
    ft=fittype('a*sin(b*x+c)+d');
    [sortY, index]=sort(Y, 'descend');
    omega=dist
    opts.StartPoint=[abs((max(Y)-min(Y))/2), pi/abs(omega), Y(1), mean(Y)]
    [fitResult, gofsine, output] = fit(X, Y, ft, opts );
    %plot(fitResult); DEBUG
    %try plotting a 4 degree polynomial
    [polyn4, gofpolyn] = fit(Xsort,Ysort,'poly4');
    %check the gofs and pick the lowest one
    if gofpolyn.rmse< gofsine.rmse
        %output polynomial coefficients
        ParamStr=sprintf("a4: %.2f, a3: %.2f, a2: %.2f, a1: %.2f, RMSE: %.2f", polyn4(1), polyn4(2), polyn4(3), polyn4(4), gofpolyn.rmse)
        yfitted=polyn4(X);
    else
        %output afpo of sine in paramstr
        ParamStr=sprintf("A: %.2f[v], DC: %.2f[v], F: %.2f[Hz], P: %.2f [deg], RMSE: %.2f", fitResult.a, fitResult.d, fitResult.b/(2*pi), rad2deg(fitResult.c), gofsine.rmse)
        yfitted=fitResult(X);
    end
end


%function to order corners
function [A,B,C,D] = orderCorners(Corners)
%must find corner A by sorting the Corners over the smallest distance to
%0,0, that is to say smallest x2+y2
distances=Corners(:,1).^2 + Corners(:,2).^2
[distances, index_distances]=sort(distances)
xA=Corners(index_distances(1), 1);
yA=Corners(index_distances(1), 2);
A=[xA, yA];
%put A at the beginning of Corners
aux=[Corners(1, 1), Corners(1, 2)]
Corners(index_distances(1), :)=aux
Corners(1, :)=A
%now we must order the B C D such that atan((y-yA)/(x-xA)) is minimal
angles=atan2((Corners(:, 2)-yA),(Corners(:, 1)-xA))
angles(1, :)=[] %delete A
%we copy corners and we delete A from it as well
CornersCopy=Corners;
CornersCopy(1, :)=[] %delete A
[angles, index_angles]=sort(angles)
%now the last 3 angles correspond to B C and D
B=[CornersCopy(index_angles(1), 1), CornersCopy(index_angles(1), 2)];
C=[CornersCopy(index_angles(2), 1), CornersCopy(index_angles(2), 2)];
D=[CornersCopy(index_angles(3), 1), CornersCopy(index_angles(3), 2)];
end
   